<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/remind4-admin-kit/templates/menu/menu--main.html.twig */
class __TwigTemplate_1d421225b524198cd83bdd47e65db393 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 19
        yield "<ul class=\"sidebar-nav\">
  ";
        // line 20
        if (($context["items"] ?? null)) {
            // line 21
            yield "    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["items"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 22
                yield "      ";
                $context["is_active"] = ((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "in_active_trail", [], "any", false, false, true, 22)) ? (" active") : (""));
                // line 23
                yield "      ";
                $context["has_children"] = ((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "below", [], "any", false, false, true, 23)) ? (" has-submenu") : (""));
                // line 24
                yield "      ";
                $context["toggle_id"] = ("submenu-" . CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, true, 24));
                // line 25
                yield "
      <li class=\"sidebar-item";
                // line 26
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["is_active"] ?? null), "html", null, true);
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["has_children"] ?? null), "html", null, true);
                yield "\">
        ";
                // line 27
                if (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "below", [], "any", false, false, true, 27)) {
                    // line 28
                    yield "          <a data-bs-target=\"#";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["toggle_id"] ?? null), "html", null, true);
                    yield "\" data-bs-toggle=\"collapse\" class=\"sidebar-link collapsed";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((($context["is_active"] ?? null)) ? (" active") : ("")));
                    yield "\">
            ";
                    // line 29
                    if (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "icon", [], "any", false, false, true, 29)) {
                        // line 30
                        yield "              <i class=\"align-middle\" data-feather=\"";
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "icon", [], "any", false, false, true, 30), "html", null, true);
                        yield "\"></i>
            ";
                    }
                    // line 32
                    yield "            <span class=\"align-middle\">";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, true, 32), "html", null, true);
                    yield "</span>
          </a>
          <ul id=\"";
                    // line 34
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["toggle_id"] ?? null), "html", null, true);
                    yield "\" class=\"sidebar-dropdown list-unstyled collapse";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((($context["is_active"] ?? null)) ? (" show") : ("")));
                    yield "\" data-bs-parent=\"#sidebar\">
            ";
                    // line 35
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "below", [], "any", false, false, true, 35));
                    $context['loop'] = [
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    ];
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["_key"] => $context["sub_item"]) {
                        // line 36
                        yield "              ";
                        $context["sub_is_active"] = ((CoreExtension::getAttribute($this->env, $this->source, $context["sub_item"], "in_active_trail", [], "any", false, false, true, 36)) ? (" active") : (""));
                        // line 37
                        yield "              ";
                        $context["sub_has_children"] = ((CoreExtension::getAttribute($this->env, $this->source, $context["sub_item"], "below", [], "any", false, false, true, 37)) ? (" has-submenu") : (""));
                        // line 38
                        yield "              ";
                        $context["sub_toggle_id"] = ((($context["toggle_id"] ?? null) . "-sub-") . CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, true, 38));
                        // line 39
                        yield "
              <li class=\"sidebar-item";
                        // line 40
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["sub_is_active"] ?? null), "html", null, true);
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["sub_has_children"] ?? null), "html", null, true);
                        yield "\">
                ";
                        // line 41
                        if (CoreExtension::getAttribute($this->env, $this->source, $context["sub_item"], "below", [], "any", false, false, true, 41)) {
                            // line 42
                            yield "                  <a data-bs-target=\"#";
                            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["sub_toggle_id"] ?? null), "html", null, true);
                            yield "\" data-bs-toggle=\"collapse\" class=\"sidebar-link collapsed";
                            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((($context["sub_is_active"] ?? null)) ? (" active") : ("")));
                            yield "\">
                    <span class=\"align-middle\">";
                            // line 43
                            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["sub_item"], "title", [], "any", false, false, true, 43), "html", null, true);
                            yield "</span>
                  </a>
                  <ul id=\"";
                            // line 45
                            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["sub_toggle_id"] ?? null), "html", null, true);
                            yield "\" class=\"sidebar-dropdown list-unstyled collapse";
                            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((($context["sub_is_active"] ?? null)) ? (" show") : ("")));
                            yield "\">
                    ";
                            // line 46
                            $context['_parent'] = $context;
                            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["sub_item"], "below", [], "any", false, false, true, 46));
                            foreach ($context['_seq'] as $context["_key"] => $context["third_item"]) {
                                // line 47
                                yield "                      <li class=\"sidebar-item";
                                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((CoreExtension::getAttribute($this->env, $this->source, $context["third_item"], "in_active_trail", [], "any", false, false, true, 47)) ? (" active") : ("")));
                                yield "\">
                        <a class=\"sidebar-link";
                                // line 48
                                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((CoreExtension::getAttribute($this->env, $this->source, $context["third_item"], "in_active_trail", [], "any", false, false, true, 48)) ? (" active") : ("")));
                                yield "\" href=\"";
                                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["third_item"], "url", [], "any", false, false, true, 48), "html", null, true);
                                yield "\">
                          <span class=\"align-middle\">";
                                // line 49
                                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["third_item"], "title", [], "any", false, false, true, 49), "html", null, true);
                                yield "</span>
                        </a>
                      </li>
                    ";
                            }
                            $_parent = $context['_parent'];
                            unset($context['_seq'], $context['_key'], $context['third_item'], $context['_parent']);
                            $context = array_intersect_key($context, $_parent) + $_parent;
                            // line 53
                            yield "                  </ul>
                ";
                        } else {
                            // line 55
                            yield "                  <a class=\"sidebar-link";
                            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((($context["sub_is_active"] ?? null)) ? (" active") : ("")));
                            yield "\" href=\"";
                            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["sub_item"], "url", [], "any", false, false, true, 55), "html", null, true);
                            yield "\">
                    <span class=\"align-middle\">";
                            // line 56
                            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["sub_item"], "title", [], "any", false, false, true, 56), "html", null, true);
                            yield "</span>
                  </a>
                ";
                        }
                        // line 59
                        yield "              </li>
            ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['sub_item'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 61
                    yield "          </ul>
        ";
                } else {
                    // line 63
                    yield "          <a class=\"sidebar-link";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((($context["is_active"] ?? null)) ? (" active") : ("")));
                    yield "\" href=\"";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, true, 63), "html", null, true);
                    yield "\">
            ";
                    // line 64
                    if (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "icon", [], "any", false, false, true, 64)) {
                        // line 65
                        yield "              <i class=\"align-middle\" data-feather=\"";
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "icon", [], "any", false, false, true, 65), "html", null, true);
                        yield "\"></i>
            ";
                    }
                    // line 67
                    yield "            <span class=\"align-middle\">";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, true, 67), "html", null, true);
                    yield "</span>
          </a>
        ";
                }
                // line 70
                yield "      </li>
    ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 72
            yield "  ";
        }
        // line 73
        yield "</ul>

";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["items", "loop"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/remind4-admin-kit/templates/menu/menu--main.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  268 => 73,  265 => 72,  250 => 70,  243 => 67,  237 => 65,  235 => 64,  228 => 63,  224 => 61,  209 => 59,  203 => 56,  196 => 55,  192 => 53,  182 => 49,  176 => 48,  171 => 47,  167 => 46,  161 => 45,  156 => 43,  149 => 42,  147 => 41,  142 => 40,  139 => 39,  136 => 38,  133 => 37,  130 => 36,  113 => 35,  107 => 34,  101 => 32,  95 => 30,  93 => 29,  86 => 28,  84 => 27,  79 => 26,  76 => 25,  73 => 24,  70 => 23,  67 => 22,  49 => 21,  47 => 20,  44 => 19,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/custom/remind4-admin-kit/templates/menu/menu--main.html.twig", "/home/jithesh/remindy4_13-02-new/themes/custom/remind4-admin-kit/templates/menu/menu--main.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 20, "for" => 21, "set" => 22];
        static $filters = ["escape" => 26];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['if', 'for', 'set'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
