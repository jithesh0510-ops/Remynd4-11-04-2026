<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/remind4-admin-kit/templates/page.html.twig */
class __TwigTemplate_ac09f06f7b9e34e96468844d99b98ed5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 9
        yield "<!DOCTYPE html>
<html";
        // line 10
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["html_attributes"] ?? null), "html", null, true);
        yield ">
<head>
  <head-placeholder token=\"";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(($context["placeholder_token"] ?? null));
        yield "\">
  <title>";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->safeJoin($this->env, ($context["head_title"] ?? null), " | "));
        yield "</title>
  <css-placeholder token=\"";
        // line 14
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(($context["placeholder_token"] ?? null));
        yield "\">
  <js-placeholder token=\"";
        // line 15
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(($context["placeholder_token"] ?? null));
        yield "\">
</head>
<body";
        // line 17
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", ["remind4-admin-kit"], "method", false, false, true, 17), "html", null, true);
        yield ">
  <a href=\"#main-content\" class=\"visually-hidden focusable skip-link\">
    ";
        // line 19
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Skip to main content"));
        yield "
  </a>

  <div class=\"wrapper\">
    ";
        // line 24
        yield "    <nav id=\"sidebar\" class=\"sidebar js-sidebar\">
      <div class=\"sidebar-content js-simplebar\">
        ";
        // line 27
        yield "        <a class=\"sidebar-brand\" href=\"";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->getPath("<front>"));
        yield "\">
          ";
        // line 28
        if (($context["site_logo"] ?? null)) {
            // line 29
            yield "            <img src=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["site_logo"] ?? null), "html", null, true);
            yield "\" alt=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["site_name"] ?? null), "html", null, true);
            yield "\" />
          ";
        } else {
            // line 31
            yield "            <span class=\"align-middle\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["site_name"] ?? null), "html", null, true);
            yield "</span>
          ";
        }
        // line 33
        yield "        </a>

        ";
        // line 36
        yield "        ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 36)) {
            // line 37
            yield "          ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 37), "html", null, true);
            yield "
        ";
        } elseif (CoreExtension::getAttribute($this->env, $this->source,         // line 38
($context["page"] ?? null), "primary_menu", [], "any", false, false, true, 38)) {
            // line 39
            yield "          ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "primary_menu", [], "any", false, false, true, 39), "html", null, true);
            yield "
        ";
        }
        // line 41
        yield "      </div>
    </nav>

    ";
        // line 45
        yield "    <div class=\"main\">
      ";
        // line 47
        yield "      <nav class=\"navbar navbar-expand navbar-light navbar-bg\">
        <a class=\"sidebar-toggle js-sidebar-toggle\">
          <i class=\"hamburger align-self-center\"></i>
        </a>

        <div class=\"navbar-collapse collapse\">
          <ul class=\"navbar-nav navbar-align\">
            ";
        // line 55
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "language_switcher", [], "any", false, false, true, 55)) {
            // line 56
            yield "              <li class=\"nav-item\">
                ";
            // line 57
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "language_switcher", [], "any", false, false, true, 57), "html", null, true);
            yield "
              </li>
            ";
        }
        // line 60
        yield "
            ";
        // line 62
        yield "            ";
        if ((array_key_exists("notification_count", $context) && (($context["notification_count"] ?? null) > 0))) {
            // line 63
            yield "              <li class=\"nav-item dropdown\">
                <a class=\"nav-icon dropdown-toggle\" href=\"#\" id=\"alertsDropdown\" role=\"button\" data-bs-toggle=\"dropdown\" aria-expanded=\"false\">
                  <div class=\"position-relative\">
                    <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-bell align-middle\">
                      <path d=\"M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9\"></path>
                      <path d=\"M13.73 21a2 2 0 0 1-3.46 0\"></path>
                    </svg>
                    <span class=\"indicator\">";
            // line 70
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["notification_count"] ?? null), "html", null, true);
            yield "</span>
                  </div>
                </a>
                <ul class=\"dropdown-menu dropdown-menu-lg dropdown-menu-end py-0\" aria-labelledby=\"alertsDropdown\">
                  <li>
                    <div class=\"dropdown-menu-header\">
                      ";
            // line 76
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["notification_count"] ?? null), "html", null, true);
            yield " ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("New Notification"));
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar((((($context["notification_count"] ?? null) > 1)) ? ("s") : ("")));
            yield "
                    </div>
                  </li>
                  <li>
                    <div class=\"list-group\">
                      ";
            // line 81
            if (($context["messages"] ?? null)) {
                // line 82
                yield "                        ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["messages"] ?? null));
                foreach ($context['_seq'] as $context["type"] => $context["message_list"]) {
                    // line 83
                    yield "                          ";
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable($context["message_list"]);
                    foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                        // line 84
                        yield "                            <a href=\"#\" class=\"list-group-item\">
                              <div class=\"row g-0 align-items-center\">
                                <div class=\"col-2\">
                                  ";
                        // line 87
                        if (($context["type"] == "error")) {
                            // line 88
                            yield "                                    <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-alert-circle text-danger\">
                                      <circle cx=\"12\" cy=\"12\" r=\"10\"></circle>
                                      <line x1=\"12\" y1=\"8\" x2=\"12\" y2=\"12\"></line>
                                      <line x1=\"12\" y1=\"16\" x2=\"12.01\" y2=\"16\"></line>
                                    </svg>
                                  ";
                        } elseif ((                        // line 93
$context["type"] == "warning")) {
                            // line 94
                            yield "                                    <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-bell text-warning\">
                                      <path d=\"M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9\"></path>
                                      <path d=\"M13.73 21a2 2 0 0 1-3.46 0\"></path>
                                    </svg>
                                  ";
                        } else {
                            // line 99
                            yield "                                    <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-home text-primary\">
                                      <path d=\"M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>
                                      <polyline points=\"9 22 9 12 15 12 15 22\"></polyline>
                                    </svg>
                                  ";
                        }
                        // line 104
                        yield "                                </div>
                                <div class=\"col-10\">
                                  <div class=\"text-dark\">";
                        // line 106
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $context["message"], "html", null, true);
                        yield "</div>
                                  <div class=\"text-muted small mt-1\">";
                        // line 107
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Just now"));
                        yield "</div>
                                </div>
                              </div>
                            </a>
                          ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['message'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 112
                    yield "                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['type'], $context['message_list'], $context['_parent']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 113
                yield "                      ";
            }
            // line 114
            yield "                    </div>
                  </li>
                  <li>
                    <div class=\"dropdown-menu-footer\">
                      <a href=\"";
            // line 118
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->getPath("dblog.overview"));
            yield "\" class=\"text-muted\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Show all notifications"));
            yield "</a>
                    </div>
                  </li>
                </ul>
              </li>
            ";
        }
        // line 124
        yield "
            ";
        // line 126
        yield "            ";
        // line 135
        yield "
            ";
        // line 137
        yield "            ";
        if (($context["logged_in"] ?? null)) {
            // line 138
            yield "              <li class=\"nav-item dropdown\">
                ";
            // line 140
            yield "                <a class=\"nav-icon dropdown-toggle d-inline-block d-sm-none\" href=\"#\" role=\"button\" id=\"userDropdownMobile\" data-bs-toggle=\"dropdown\" aria-expanded=\"false\">
                  <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-settings align-middle\">
                    <circle cx=\"12\" cy=\"12\" r=\"3\"></circle>
                    <path d=\"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z\"></path>
                  </svg>
                </a>
                ";
            // line 147
            yield "                <a class=\"nav-link dropdown-toggle d-none d-sm-inline-block\" href=\"#\" role=\"button\" id=\"userDropdown\" data-bs-toggle=\"dropdown\" aria-expanded=\"false\">
                  ";
            // line 148
            if (($context["user_picture_url"] ?? null)) {
                // line 149
                yield "                    <img src=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["user_picture_url"] ?? null), "html", null, true);
                yield "\" class=\"avatar img-fluid rounded-circle me-1\" alt=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["user_name"] ?? null), "html", null, true);
                yield "\" />
                  ";
            } else {
                // line 151
                yield "                    <div
                      class=\"rounded-circle d-inline-flex align-items-center justify-content-center me-1\"
                      style=\"width: 2rem; height: 2rem; background-color: #e5e7eb; color: #6b7280; font-size: 0.875rem; font-weight: 600;\"
                    >
                      ";
                // line 155
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, Twig\Extension\CoreExtension::upper($this->env->getCharset(), Twig\Extension\CoreExtension::slice($this->env->getCharset(), ($context["user_name"] ?? null), 0, 1)), "html", null, true);
                yield "
                    </div>
                  ";
            }
            // line 158
            yield "                  <span class=\"text-dark\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["user_name"] ?? null), "html", null, true);
            yield "</span>
                </a>
                <ul class=\"dropdown-menu dropdown-menu-end\" aria-labelledby=\"userDropdown\">
                  <li>
                    <a class=\"dropdown-item\" href=\"";
            // line 162
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getPath("entity.user.canonical", ["user" => ($context["user_id"] ?? null)]), "html", null, true);
            yield "\">
                      <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-user align-middle me-1\">
                        <path d=\"M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2\"></path>
                        <circle cx=\"12\" cy=\"7\" r=\"4\"></circle>
                      </svg> ";
            // line 166
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Profile"));
            yield "
                    </a>
                  </li>
                  ";
            // line 169
            if (($context["is_admin"] ?? null)) {
                // line 170
                yield "                    <li>
                      <a class=\"dropdown-item\" href=\"";
                // line 171
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->getPath("system.admin"));
                yield "\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-pie-chart align-middle me-1\">
                          <path d=\"M21.21 15.89A10 10 0 1 1 8 2.83\"></path>
                          <path d=\"M22 12A10 10 0 0 0 12 2v10z\"></path>
                        </svg> ";
                // line 175
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Analytics"));
                yield "
                      </a>
                    </li>
                  ";
            }
            // line 179
            yield "                  <li><hr class=\"dropdown-divider\"></li>
                  <li>
                    <a class=\"dropdown-item\" href=\"";
            // line 181
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getPath("entity.user.edit_form", ["user" => ($context["user_id"] ?? null)]), "html", null, true);
            yield "\">
                      <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-settings align-middle me-1\">
                        <circle cx=\"12\" cy=\"12\" r=\"3\"></circle>
                        <path d=\"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z\"></path>
                      </svg> ";
            // line 185
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Settings & Privacy"));
            yield "
                    </a>
                  </li>
                  <li>
                    <a class=\"dropdown-item\" href=\"#\">
                      <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-help-circle align-middle me-1\">
                        <circle cx=\"12\" cy=\"12\" r=\"10\"></circle>
                        <path d=\"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3\"></path>
                        <line x1=\"12\" y1=\"17\" x2=\"12.01\" y2=\"17\"></line>
                      </svg> ";
            // line 194
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Help Center"));
            yield "
                    </a>
                  </li>
                  <li><hr class=\"dropdown-divider\"></li>
                  <li>
                    <a class=\"dropdown-item\" href=\"";
            // line 199
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->getPath("user.logout"));
            yield "\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Log out"));
            yield "</a>
                  </li>
                </ul>
              </li>
            ";
        } else {
            // line 204
            yield "              <li class=\"nav-item\">
                <a class=\"nav-link\" href=\"";
            // line 205
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->getPath("user.login"));
            yield "\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Log in"));
            yield "</a>
              </li>
            ";
        }
        // line 208
        yield "          </ul>
        </div>
      </nav>

      ";
        // line 213
        yield "      <main class=\"content\" id=\"main-content\">
        <div class=\"container-fluid p-0\">
          ";
        // line 216
        yield "          ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "breadcrumb", [], "any", false, false, true, 216)) {
            // line 217
            yield "            <div class=\"row mb-3\">
              <div class=\"col-12\">
                ";
            // line 219
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "breadcrumb", [], "any", false, false, true, 219), "html", null, true);
            yield "
              </div>
            </div>
          ";
        }
        // line 223
        yield "
          ";
        // line 225
        yield "          ";
        if (( !array_key_exists("hide_page_title", $context) ||  !($context["hide_page_title"] ?? null))) {
            // line 226
            yield "            ";
            if ((($_v0 = ($context["page"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess && in_array($_v0::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v0["#title"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "#title", [], "array", false, false, true, 226))) {
                // line 227
                yield "              <h1 class=\"h3 mb-3\"><strong>";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, (($_v1 = ($context["page"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess && in_array($_v1::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v1["#title"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "#title", [], "array", false, false, true, 227)), "html", null, true);
                yield "</strong></h1>
            ";
            } elseif (            // line 228
($context["title"] ?? null)) {
                // line 229
                yield "              <h1 class=\"h3 mb-3\"><strong>";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["title"] ?? null), "html", null, true);
                yield "</strong></h1>
            ";
            }
            // line 231
            yield "          ";
        }
        // line 232
        yield "
          ";
        // line 234
        yield "          ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "highlighted", [], "any", false, false, true, 234)) {
            // line 235
            yield "            <div class=\"row mb-3\">
              <div class=\"col-12\">
                ";
            // line 237
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "highlighted", [], "any", false, false, true, 237), "html", null, true);
            yield "
              </div>
            </div>
          ";
        }
        // line 241
        yield "
          ";
        // line 243
        yield "          ";
        if (($context["messages"] ?? null)) {
            // line 244
            yield "            <div class=\"row mb-3\">
              <div class=\"col-12\">
                ";
            // line 246
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["messages"] ?? null), "html", null, true);
            yield "
              </div>
            </div>
          ";
        }
        // line 250
        yield "          
          ";
        // line 252
        yield "          ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "highlighted", [], "any", false, false, true, 252)) {
            // line 253
            yield "            <div class=\"row mb-3\">
              <div class=\"col-12\">
                ";
            // line 255
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "highlighted", [], "any", false, false, true, 255), "html", null, true);
            yield "
              </div>
            </div>
          ";
        }
        // line 259
        yield "
          ";
        // line 261
        yield "          <div class=\"row\">
            <div class=\"col-12\">
              ";
        // line 263
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 263), "html", null, true);
        yield "
            </div>
          </div>

          ";
        // line 268
        yield "          ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "help", [], "any", false, false, true, 268)) {
            // line 269
            yield "            <div class=\"row mt-3\">
              <div class=\"col-12\">
                ";
            // line 271
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "help", [], "any", false, false, true, 271), "html", null, true);
            yield "
              </div>
            </div>
          ";
        }
        // line 275
        yield "        </div>
      </main>

      ";
        // line 279
        yield "      <footer class=\"footer\">
        <div class=\"container-fluid\">
          <div class=\"row text-muted\">
            <div class=\"col-6 text-start\">
              ";
        // line 283
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_first", [], "any", false, false, true, 283)) {
            // line 284
            yield "                ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_first", [], "any", false, false, true, 284), "html", null, true);
            yield "
              ";
        } elseif (CoreExtension::getAttribute($this->env, $this->source,         // line 285
($context["page"] ?? null), "footer", [], "any", false, false, true, 285)) {
            // line 286
            yield "                ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer", [], "any", false, false, true, 286), "html", null, true);
            yield "
              ";
        } else {
            // line 288
            yield "                <p class=\"mb-0\">
                  <a href=\"";
            // line 289
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->getPath("<front>"));
            yield "\" class=\"text-muted\"><strong>";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["site_name"] ?? null), "html", null, true);
            yield "</strong></a> &copy; ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Twig\Extension\CoreExtension']->formatDate("now", "Y"), "html", null, true);
            yield "
                </p>
              ";
        }
        // line 292
        yield "            </div>
            <div class=\"col-6 text-end\">
              ";
        // line 294
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_second", [], "any", false, false, true, 294)) {
            // line 295
            yield "                ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_second", [], "any", false, false, true, 295), "html", null, true);
            yield "
              ";
        } else {
            // line 297
            yield "                <p class=\"mb-0\">
                  ";
            // line 298
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Powered by"));
            yield " <a href=\"https://www.drupal.org\" class=\"text-muted\" target=\"_blank\">Drupal</a>
                </p>
              ";
        }
        // line 301
        yield "            </div>
          </div>
          ";
        // line 303
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_third", [], "any", false, false, true, 303) || CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_fourth", [], "any", false, false, true, 303))) {
            // line 304
            yield "            <div class=\"row text-muted mt-2\">
              <div class=\"col-6 text-start\">
                ";
            // line 306
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_third", [], "any", false, false, true, 306)) {
                // line 307
                yield "                  ";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_third", [], "any", false, false, true, 307), "html", null, true);
                yield "
                ";
            }
            // line 309
            yield "              </div>
              <div class=\"col-6 text-end\">
                ";
            // line 311
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_fourth", [], "any", false, false, true, 311)) {
                // line 312
                yield "                  ";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_fourth", [], "any", false, false, true, 312), "html", null, true);
                yield "
                ";
            }
            // line 314
            yield "              </div>
            </div>
          ";
        }
        // line 317
        yield "        </div>
      </footer>
    </div>
  </div>

  <js-bottom-placeholder token=\"";
        // line 322
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(($context["placeholder_token"] ?? null));
        yield "\">
</body>
</html>

";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["html_attributes", "placeholder_token", "head_title", "attributes", "site_logo", "site_name", "page", "notification_count", "messages", "logged_in", "user_picture_url", "user_name", "user_id", "is_admin", "hide_page_title", "title"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/remind4-admin-kit/templates/page.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  646 => 322,  639 => 317,  634 => 314,  628 => 312,  626 => 311,  622 => 309,  616 => 307,  614 => 306,  610 => 304,  608 => 303,  604 => 301,  598 => 298,  595 => 297,  589 => 295,  587 => 294,  583 => 292,  573 => 289,  570 => 288,  564 => 286,  562 => 285,  557 => 284,  555 => 283,  549 => 279,  544 => 275,  537 => 271,  533 => 269,  530 => 268,  523 => 263,  519 => 261,  516 => 259,  509 => 255,  505 => 253,  502 => 252,  499 => 250,  492 => 246,  488 => 244,  485 => 243,  482 => 241,  475 => 237,  471 => 235,  468 => 234,  465 => 232,  462 => 231,  456 => 229,  454 => 228,  449 => 227,  446 => 226,  443 => 225,  440 => 223,  433 => 219,  429 => 217,  426 => 216,  422 => 213,  416 => 208,  408 => 205,  405 => 204,  395 => 199,  387 => 194,  375 => 185,  368 => 181,  364 => 179,  357 => 175,  350 => 171,  347 => 170,  345 => 169,  339 => 166,  332 => 162,  324 => 158,  318 => 155,  312 => 151,  304 => 149,  302 => 148,  299 => 147,  291 => 140,  288 => 138,  285 => 137,  282 => 135,  280 => 126,  277 => 124,  266 => 118,  260 => 114,  257 => 113,  251 => 112,  240 => 107,  236 => 106,  232 => 104,  225 => 99,  218 => 94,  216 => 93,  209 => 88,  207 => 87,  202 => 84,  197 => 83,  192 => 82,  190 => 81,  179 => 76,  170 => 70,  161 => 63,  158 => 62,  155 => 60,  149 => 57,  146 => 56,  143 => 55,  134 => 47,  131 => 45,  126 => 41,  120 => 39,  118 => 38,  113 => 37,  110 => 36,  106 => 33,  100 => 31,  92 => 29,  90 => 28,  85 => 27,  81 => 24,  74 => 19,  69 => 17,  64 => 15,  60 => 14,  56 => 13,  52 => 12,  47 => 10,  44 => 9,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/custom/remind4-admin-kit/templates/page.html.twig", "/home/jithesh/remindy4_13-02-new/themes/custom/remind4-admin-kit/templates/page.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 28, "for" => 82];
        static $filters = ["escape" => 10, "raw" => 12, "safe_join" => 13, "t" => 19, "upper" => 155, "slice" => 155, "date" => 289];
        static $functions = ["path" => 27];

        try {
            $this->sandbox->checkSecurity(
                ['if', 'for'],
                ['escape', 'raw', 'safe_join', 't', 'upper', 'slice', 'date'],
                ['path'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
