<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/remind4-admin-kit/templates/user.html.twig */
class __TwigTemplate_f77be387bb2caa79d52a5e9e3dd6dc91 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 18
        yield "
";
        // line 20
        if (((($context["view_mode"] ?? null) == "full") && (($context["route_name"] ?? null) == "entity.user.canonical"))) {
            // line 21
            yield "
";
            // line 23
            $context["display_name"] = CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "display_name", [], "any", false, false, true, 23);
            // line 24
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_full_name", [], "any", true, true, true, 24) && CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_full_name", [], "any", false, false, true, 24), "value", [], "any", false, false, true, 24))) {
                // line 25
                yield "  ";
                $context["display_name"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_full_name", [], "any", false, false, true, 25), "value", [], "any", false, false, true, 25);
            } elseif ((CoreExtension::getAttribute($this->env, $this->source,             // line 26
($context["user"] ?? null), "field_first_name", [], "any", true, true, true, 26) && CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_first_name", [], "any", false, false, true, 26), "value", [], "any", false, false, true, 26))) {
                // line 27
                yield "  ";
                $context["display_name"] = (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_first_name", [], "any", false, false, true, 27), "value", [], "any", false, false, true, 27) . (((CoreExtension::getAttribute($this->env, $this->source,                 // line 28
($context["user"] ?? null), "field_last_name", [], "any", true, true, true, 28) && CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_last_name", [], "any", false, false, true, 28), "value", [], "any", false, false, true, 28))) ? ((" " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_last_name", [], "any", false, false, true, 28), "value", [], "any", false, false, true, 28))) : ("")));
            }
            // line 30
            yield "
";
            // line 31
            $context["email"] = (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "mail", [], "any", false, true, true, 31), "value", [], "any", true, true, true, 31) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "mail", [], "any", false, false, true, 31), "value", [], "any", false, false, true, 31)))) ? (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "mail", [], "any", false, false, true, 31), "value", [], "any", false, false, true, 31)) : (""));
            // line 32
            yield "
<div class=\"container-fluid p-0\">
  <div class=\"mb-3\">
    <h1 class=\"h3 d-inline align-middle\">";
            // line 35
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Profile"));
            yield "</h1>
  </div>

  <div class=\"row\">
    ";
            // line 40
            yield "    <div class=\"col-md-4 col-xl-3\">
      <div class=\"card mb-3\">
        <div class=\"card-header\">
          <h5 class=\"card-title mb-0\">";
            // line 43
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Profile Details"));
            yield "</h5>
        </div>
        <div class=\"card-body text-center\">
          ";
            // line 47
            yield "          ";
            if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "user_picture", [], "any", false, false, true, 47), "entity", [], "any", false, false, true, 47) && CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "user_picture", [], "any", false, false, true, 47), "entity", [], "any", false, false, true, 47), "uri", [], "any", false, false, true, 47), "value", [], "any", false, false, true, 47))) {
                // line 48
                yield "            <img
              src=\"";
                // line 49
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "user_picture", [], "any", false, false, true, 49), "entity", [], "any", false, false, true, 49), "uri", [], "any", false, false, true, 49), "value", [], "any", false, false, true, 49)), "html", null, true);
                yield "\"
              alt=\"";
                // line 50
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["display_name"] ?? null), "html", null, true);
                yield "\"
              class=\"img-fluid rounded-circle mb-2\"
              width=\"128\"
              height=\"128\"
            />
          ";
            } else {
                // line 56
                yield "            <div
              class=\"rounded-circle mb-2 d-inline-flex align-items-center justify-content-center\"
              style=\"width: 128px; height: 128px; background-color: #e5e7eb; color: #6b7280; font-size: 3rem; font-weight: 600;\"
            >
              ";
                // line 60
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, Twig\Extension\CoreExtension::upper($this->env->getCharset(), Twig\Extension\CoreExtension::slice($this->env->getCharset(), ($context["display_name"] ?? null), 0, 1)), "html", null, true);
                yield "
            </div>
          ";
            }
            // line 63
            yield "
          <h5 class=\"card-title mb-0\">";
            // line 64
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["display_name"] ?? null), "html", null, true);
            yield "</h5>

          ";
            // line 66
            if (($context["email"] ?? null)) {
                // line 67
                yield "            <div class=\"text-muted mb-2\">";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["email"] ?? null), "html", null, true);
                yield "</div>
          ";
            }
            // line 69
            yield "
          ";
            // line 71
            yield "          ";
            if ((($context["logged_in"] ?? null) && (CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, true, 71) == ($context["user_id"] ?? null)))) {
                // line 72
                yield "            <div>
              <a class=\"btn btn-primary btn-sm\" href=\"";
                // line 73
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getPath("entity.user.edit_form", ["user" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, true, 73)]), "html", null, true);
                yield "\">
                ";
                // line 74
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Edit profile"));
                yield "
              </a>
            </div>
          ";
            }
            // line 78
            yield "        </div>

        ";
            // line 81
            yield "        <hr class=\"my-0\" />
        <div class=\"card-body\">
          <h5 class=\"h6 card-title mb-2\">";
            // line 83
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Skills & roles"));
            yield "</h5>

          <div class=\"d-flex flex-wrap gap-1\">
            ";
            // line 87
            yield "            <span class=\"badge bg-primary\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["display_name"] ?? null), "html", null, true);
            yield "</span>

            ";
            // line 90
            yield "            ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "roles", [], "any", true, true, true, 90) && Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "roles", [], "any", false, false, true, 90)))) {
                // line 91
                yield "              ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "roles", [], "any", false, false, true, 91));
                foreach ($context['_seq'] as $context["_key"] => $context["role_item"]) {
                    // line 92
                    yield "                ";
                    if (CoreExtension::getAttribute($this->env, $this->source, $context["role_item"], "entity", [], "any", false, false, true, 92)) {
                        // line 93
                        yield "                  <span class=\"badge bg-secondary\">";
                        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["role_item"], "entity", [], "any", false, false, true, 93), "label", [], "any", false, false, true, 93), "html", null, true);
                        yield "</span>
                ";
                    }
                    // line 95
                    yield "              ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['role_item'], $context['_parent']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 96
                yield "            ";
            }
            // line 97
            yield "          </div>
        </div>

        ";
            // line 101
            yield "        <hr class=\"my-0\" />
        <div class=\"card-body\">
          <h5 class=\"h6 card-title\">";
            // line 103
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("About"));
            yield "</h5>
          <ul class=\"list-unstyled mb-0\">
            ";
            // line 106
            yield "            ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_address", [], "any", true, true, true, 106) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_address", [], "any", false, false, true, 106), 0, [], "any", false, false, true, 106)))) {
                // line 107
                yield "              ";
                $context["addr"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_address", [], "any", false, false, true, 107), 0, [], "any", false, false, true, 107);
                // line 108
                yield "              ";
                $context["locality"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["addr"] ?? null), "locality", [], "any", true, true, true, 108) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["addr"] ?? null), "locality", [], "any", false, false, true, 108)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["addr"] ?? null), "locality", [], "any", false, false, true, 108)) : (""));
                // line 109
                yield "              ";
                $context["region"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["addr"] ?? null), "administrative_area", [], "any", true, true, true, 109) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["addr"] ?? null), "administrative_area", [], "any", false, false, true, 109)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["addr"] ?? null), "administrative_area", [], "any", false, false, true, 109)) : (""));
                // line 110
                yield "              ";
                $context["country"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["addr"] ?? null), "country_code", [], "any", true, true, true, 110) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["addr"] ?? null), "country_code", [], "any", false, false, true, 110)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["addr"] ?? null), "country_code", [], "any", false, false, true, 110)) : (""));
                // line 111
                yield "              ";
                $context["location_parts"] = [];
                // line 112
                yield "              ";
                if (($context["locality"] ?? null)) {
                    $context["location_parts"] = Twig\Extension\CoreExtension::merge(($context["location_parts"] ?? null), [($context["locality"] ?? null)]);
                }
                // line 113
                yield "              ";
                if (($context["region"] ?? null)) {
                    $context["location_parts"] = Twig\Extension\CoreExtension::merge(($context["location_parts"] ?? null), [($context["region"] ?? null)]);
                }
                // line 114
                yield "              ";
                if (($context["country"] ?? null)) {
                    $context["location_parts"] = Twig\Extension\CoreExtension::merge(($context["location_parts"] ?? null), [($context["country"] ?? null)]);
                }
                // line 115
                yield "              ";
                if (($context["location_parts"] ?? null)) {
                    // line 116
                    yield "                <li class=\"mb-1\">
                  <span class=\"feather-sm me-1\" data-feather=\"home\"></span>
                  ";
                    // line 118
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Lives in"));
                    yield " ";
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, Twig\Extension\CoreExtension::join(($context["location_parts"] ?? null), ", "), "html", null, true);
                    yield "
                </li>
              ";
                }
                // line 121
                yield "            ";
            }
            // line 122
            yield "
            ";
            // line 124
            yield "            ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_company", [], "any", true, true, true, 124) && CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_company", [], "any", false, false, true, 124), "entity", [], "any", false, false, true, 124))) {
                // line 125
                yield "              <li class=\"mb-1\">
                <span class=\"feather-sm me-1\" data-feather=\"briefcase\"></span>
                ";
                // line 127
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Works at"));
                yield " ";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_company", [], "any", false, false, true, 127), "entity", [], "any", false, false, true, 127), "label", [], "any", false, false, true, 127), "html", null, true);
                yield "
              </li>
            ";
            }
            // line 130
            yield "          </ul>
        </div>

        ";
            // line 134
            yield "        <hr class=\"my-0\" />
        <div class=\"card-body\">
          <h5 class=\"h6 card-title\">";
            // line 136
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Elsewhere"));
            yield "</h5>
          <ul class=\"list-unstyled mb-0\">
            ";
            // line 138
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_website", [], "any", true, true, true, 138) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_website", [], "any", false, false, true, 138), 0, [], "any", false, false, true, 138)))) {
                // line 139
                yield "              ";
                $context["website_item"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_website", [], "any", false, false, true, 139), 0, [], "any", false, false, true, 139);
                // line 140
                yield "              ";
                if (CoreExtension::getAttribute($this->env, $this->source, ($context["website_item"] ?? null), "uri", [], "any", false, false, true, 140)) {
                    // line 141
                    yield "                <li class=\"mb-1\">
                  <a href=\"";
                    // line 142
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["website_item"] ?? null), "uri", [], "any", false, false, true, 142), "html", null, true);
                    yield "\" target=\"_blank\" rel=\"noopener noreferrer\">
                    ";
                    // line 143
                    yield ((CoreExtension::getAttribute($this->env, $this->source, ($context["website_item"] ?? null), "title", [], "any", false, false, true, 143)) ? ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["website_item"] ?? null), "title", [], "any", false, false, true, 143), "html", null, true)) : ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["website_item"] ?? null), "uri", [], "any", false, false, true, 143), "html", null, true)));
                    yield "
                  </a>
                </li>
              ";
                }
                // line 147
                yield "            ";
            } else {
                // line 148
                yield "              <li class=\"mb-1 text-muted\">";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("No external links added"));
                yield "</li>
            ";
            }
            // line 150
            yield "          </ul>
        </div>

        ";
            // line 154
            yield "        <hr class=\"my-0\" />
        <div class=\"card-body\">
          <h5 class=\"h6 card-title\">";
            // line 156
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Profile information"));
            yield "</h5>

          <div class=\"mb-3\">
            <div class=\"text-muted text-uppercase small mb-1\">";
            // line 159
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Member for"));
            yield "</div>
            <div class=\"fw-semibold\">
              ";
            // line 161
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "member_for", [], "any", true, true, true, 161)) {
                // line 162
                yield "                ";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "member_for", [], "any", false, false, true, 162), "html", null, true);
                yield "
              ";
            } else {
                // line 164
                yield "                ";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("n/a"));
                yield "
              ";
            }
            // line 166
            yield "            </div>
          </div>

          <div class=\"row\">
            <div class=\"col-sm-6 mb-3\">
              <div class=\"text-muted small\">";
            // line 171
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Full Name"));
            yield "</div>
              <div class=\"fw-semibold\">
                ";
            // line 173
            yield (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_full_name", [], "any", false, true, true, 173), "value", [], "any", true, true, true, 173) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_full_name", [], "any", false, false, true, 173), "value", [], "any", false, false, true, 173)))) ? ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_full_name", [], "any", false, false, true, 173), "value", [], "any", false, false, true, 173), "html", null, true)) : ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["display_name"] ?? null), "html", null, true)));
            yield "
              </div>
            </div>

            <div class=\"col-sm-6 mb-3\">
              <div class=\"text-muted small\">";
            // line 178
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("First Name"));
            yield "</div>
              <div class=\"fw-semibold\">
                ";
            // line 180
            yield (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_first_name", [], "any", false, true, true, 180), "value", [], "any", true, true, true, 180) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_first_name", [], "any", false, false, true, 180), "value", [], "any", false, false, true, 180)))) ? ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_first_name", [], "any", false, false, true, 180), "value", [], "any", false, false, true, 180), "html", null, true)) : ("-"));
            yield "
              </div>
            </div>

            <div class=\"col-sm-6 mb-3\">
              <div class=\"text-muted small\">";
            // line 185
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Last Name"));
            yield "</div>
              <div class=\"fw-semibold\">
                ";
            // line 187
            yield (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_last_name", [], "any", false, true, true, 187), "value", [], "any", true, true, true, 187) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_last_name", [], "any", false, false, true, 187), "value", [], "any", false, false, true, 187)))) ? ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_last_name", [], "any", false, false, true, 187), "value", [], "any", false, false, true, 187), "html", null, true)) : ("-"));
            yield "
              </div>
            </div>

            <div class=\"col-sm-6 mb-3\">
              <div class=\"text-muted small\">";
            // line 192
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Phone No"));
            yield "</div>
              <div class=\"fw-semibold\">
                ";
            // line 194
            yield (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_phone_no", [], "any", false, true, true, 194), "value", [], "any", true, true, true, 194) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_phone_no", [], "any", false, false, true, 194), "value", [], "any", false, false, true, 194)))) ? ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_phone_no", [], "any", false, false, true, 194), "value", [], "any", false, false, true, 194), "html", null, true)) : ("-"));
            yield "
              </div>
            </div>

            <div class=\"col-sm-6 mb-0\">
              <div class=\"text-muted small\">";
            // line 199
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Is Delete"));
            yield "</div>
              ";
            // line 200
            $context["is_delete"] = (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_is_delete", [], "any", false, true, true, 200), "value", [], "any", true, true, true, 200) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_is_delete", [], "any", false, false, true, 200), "value", [], "any", false, false, true, 200)))) ? (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "field_is_delete", [], "any", false, false, true, 200), "value", [], "any", false, false, true, 200)) : (0));
            // line 201
            yield "              <div class=\"fw-semibold\">
                ";
            // line 202
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((($context["is_delete"] ?? null)) ? (t("On")) : (t("Off"))));
            yield "
              </div>
            </div>
          </div>

          ";
            // line 208
            yield "          ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "masquerade", [], "any", true, true, true, 208)) {
                // line 209
                yield "            <hr class=\"my-3\" />
            <div class=\"small\">
              ";
                // line 211
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "masquerade", [], "any", false, false, true, 211), "html", null, true);
                yield "
            </div>
          ";
            }
            // line 214
            yield "
          ";
            // line 216
            yield "          ";
            if ((array_key_exists("assigned_profiles", $context) && ($context["assigned_profiles"] ?? null))) {
                // line 217
                yield "            <hr class=\"my-3\" />
            <h5 class=\"h6 card-title\">";
                // line 218
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Assigned profiles"));
                yield "</h5>
            ";
                // line 219
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["assigned_profiles"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                    // line 220
                    yield "              <div class=\"assigned-profile-item border rounded-3 p-3 mb-2 bg-light\">
                <div class=\"text-muted text-uppercase small mb-2\">";
                    // line 221
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "type", [], "any", false, false, true, 221), "html", null, true);
                    yield "</div>
                <div class=\"assigned-profile-view small\">
                  ";
                    // line 223
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "view", [], "any", false, false, true, 223), "html", null, true);
                    yield "
                </div>
              </div>
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 227
                yield "          ";
            }
            // line 228
            yield "        </div>
      </div>
    </div>

    ";
            // line 233
            yield "    <div class=\"col-md-8 col-xl-9\">
      <div class=\"card\">
        <div class=\"card-header\">
          <h5 class=\"card-title mb-0\">";
            // line 236
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Recent activity"));
            yield "</h5>
        </div>
        <div class=\"card-body\">
          ";
            // line 241
            yield "          ";
            $context["extra"] = $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter(($context["content"] ?? null), "user_picture", "member_for", "masquerade", "field_full_name", "field_first_name", "field_last_name", "field_phone_no", "field_is_delete");
            // line 251
            yield "
          ";
            // line 252
            if ($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(($context["extra"] ?? null))) {
                // line 253
                yield "            ";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["extra"] ?? null), "html", null, true);
                yield "
          ";
            } else {
                // line 255
                yield "            <div class=\"text-muted small\">
              ";
                // line 256
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("No submissions found."));
                yield "
            </div>
          ";
            }
            // line 259
            yield "        </div>
      </div>
    </div>
  </div>
</div>
";
        } else {
            // line 265
            yield "  ";
            // line 266
            yield "  <article";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", ["profile"], "method", false, false, true, 266), "html", null, true);
            yield ">
    ";
            // line 267
            if (($context["content"] ?? null)) {
                // line 268
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["content"] ?? null), "html", null, true);
            }
            // line 270
            yield "  </article>
";
        }
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["view_mode", "route_name", "user", "logged_in", "user_id", "content", "assigned_profiles", "attributes"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/remind4-admin-kit/templates/user.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  556 => 270,  553 => 268,  551 => 267,  546 => 266,  544 => 265,  536 => 259,  530 => 256,  527 => 255,  521 => 253,  519 => 252,  516 => 251,  513 => 241,  507 => 236,  502 => 233,  496 => 228,  493 => 227,  483 => 223,  478 => 221,  475 => 220,  471 => 219,  467 => 218,  464 => 217,  461 => 216,  458 => 214,  452 => 211,  448 => 209,  445 => 208,  437 => 202,  434 => 201,  432 => 200,  428 => 199,  420 => 194,  415 => 192,  407 => 187,  402 => 185,  394 => 180,  389 => 178,  381 => 173,  376 => 171,  369 => 166,  363 => 164,  357 => 162,  355 => 161,  350 => 159,  344 => 156,  340 => 154,  335 => 150,  329 => 148,  326 => 147,  319 => 143,  315 => 142,  312 => 141,  309 => 140,  306 => 139,  304 => 138,  299 => 136,  295 => 134,  290 => 130,  282 => 127,  278 => 125,  275 => 124,  272 => 122,  269 => 121,  261 => 118,  257 => 116,  254 => 115,  249 => 114,  244 => 113,  239 => 112,  236 => 111,  233 => 110,  230 => 109,  227 => 108,  224 => 107,  221 => 106,  216 => 103,  212 => 101,  207 => 97,  204 => 96,  198 => 95,  192 => 93,  189 => 92,  184 => 91,  181 => 90,  175 => 87,  169 => 83,  165 => 81,  161 => 78,  154 => 74,  150 => 73,  147 => 72,  144 => 71,  141 => 69,  135 => 67,  133 => 66,  128 => 64,  125 => 63,  119 => 60,  113 => 56,  104 => 50,  100 => 49,  97 => 48,  94 => 47,  88 => 43,  83 => 40,  76 => 35,  71 => 32,  69 => 31,  66 => 30,  63 => 28,  61 => 27,  59 => 26,  56 => 25,  54 => 24,  52 => 23,  49 => 21,  47 => 20,  44 => 18,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/custom/remind4-admin-kit/templates/user.html.twig", "/home/jithesh/remindy4_13-02-new/themes/custom/remind4-admin-kit/templates/user.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 20, "set" => 23, "for" => 91];
        static $filters = ["t" => 35, "escape" => 49, "upper" => 60, "slice" => 60, "length" => 90, "merge" => 112, "join" => 118, "without" => 241, "render" => 252];
        static $functions = ["file_url" => 49, "path" => 73];

        try {
            $this->sandbox->checkSecurity(
                ['if', 'set', 'for'],
                ['t', 'escape', 'upper', 'slice', 'length', 'merge', 'join', 'without', 'render'],
                ['file_url', 'path'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
